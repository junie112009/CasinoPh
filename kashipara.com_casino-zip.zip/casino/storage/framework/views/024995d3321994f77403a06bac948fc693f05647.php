<?php $__env->startSection('content'); ?>
<div class="container" >
    <div class="panel panel-default">
        <div class="panel-heading" style="text-align: center; height: 150px; padding-top: 60px; ">
            <div class="row justify-content-center"><h1 style="border: solid 3px #310062; color: #310062; border-radius: 20px; width: 300px; z-index: 1;"><i>SLOT MACHINE</i></h1></div>
        </div>
        <div id="app">
        	 <slots-component :slots="<?php echo e(json_encode($slots)); ?>" :user="<?php echo e(json_encode($user)); ?>" :cash="<?php echo e(json_encode($cash)); ?>" :id="<?php echo e(json_encode($id)); ?>"></slots-component>
        </div>               
        
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>