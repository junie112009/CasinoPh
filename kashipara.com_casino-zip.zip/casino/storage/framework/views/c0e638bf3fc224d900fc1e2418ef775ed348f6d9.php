<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="container">
                    <div class="row">
                        <div class="col-md-5">
                            <div>
                                <h2>Balance replenishment</h2><br>
                                <p>(there should be a connection to payment systems, but it will work just like that)</p>
                            </div>
                        </div>                        
                        <div class="col-md-3">
                            <div >
                                <img src="<?php echo e(asset('img/okay.png')); ?>" width="90%" ></h2>
                            </div>
                        </div>
                    </div>
                </div>
                
                 
                <div class="panel-body">                                                              
                    <hr>                   
                    <form id="form1" action="<?php echo e(route('balance.update', $user->id)); ?>" method="post">
                    	<?php echo e(method_field('PUT')); ?>

                        <?php echo e(csrf_field()); ?>

                        <p>
                            <label for="cash">Your balance:</label>
                            <br>                      
                            <input type="number" name="cash" class="form-control" id="cash" required="" value="<?php echo e($user->cash); ?>" style="width: 50%" step="0.01"/>
                            <br>                                     	                            
                        </p>
                        <div class="row" style="margin-left: 5%; margin-bottom: 10%">
                            <div class="col-md-3">                        
                                <input type="submit" class="btn btn-success btn-lg" name="submit" value="Top up" style="width: 120px; font-size: 12pt;">
                            </div>
                            <div class="col-md-6">
                                <a href="<?php echo e(route('balance.edit', $user->id)); ?>" class="btn btn-danger btn-lg" style="width: 120px; font-size: 12pt;">Cancel</a>
                            </div>                        
                    	</div>
                    </form>                                                          
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>